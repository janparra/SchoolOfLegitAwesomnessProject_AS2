﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace SchoolOfLegitAwesomeness.Controllers
{
    public class studentsController : ApiController
    {
        StudentDetailsAndMarks objapi = new StudentDetailsAndMarks();
        [HttpGet]
        public IEnumerable<USP_Student_Select_Result> Get(string StudentName, string StudentEmail)
        {
            if (StudentName == null)
                StudentName = "";
            if (StudentEmail == null)
                StudentEmail = "";
            return objapi.USP_Student_Select(StudentName, StudentEmail).AsEnumerable();


        }


        // To Insert new Student Details
        [HttpGet]
        public IEnumerable<string> insertStudent(string StudentName, string StudentEmail, string Phone, string Subject, string Marks)
        {           
              return  objapi.USP_Student_Insert(StudentName, StudentEmail, Phone, Subject, Marks).AsEnumerable();           
        }

        //to Update Student Details
        [HttpGet]
        public IEnumerable<string> updateStudent(int stdID,string StudentName, string StudentEmail, string Phone, string Subject, string Marks)
        {
            return objapi.USP_Student_Update(stdID,StudentName, StudentEmail, Phone, Subject, Marks).AsEnumerable();
        }


        //to Update Student Details
        [HttpGet]
        public string deleteStudent(int stdID)
        {
            objapi.USP_Student_Delete(stdID);
            objapi.SaveChanges();
            return "deleted";
        }
    }
}
